cd thirdparty


#Download and install unixODBC
sudo yum install unixODBC unixODBC-devel libtool-ltdl libtool-ltdl-devel
sudo apt-get install unixODBC unixODBC-dev 

#Download and Install JSONCpp
cd json

wget http://downloads.sourceforge.net/project/scons/scons-local/2.1.0/scons-local-2.1.0.tar.gz
wget http://downloads.sourceforge.net/project/jsoncpp/jsoncpp/0.6.0-rc2/jsoncpp-src-0.6.0-rc2.tar.gz

tar -xvf jsoncpp-src-0.6.0-rc2.tar.gz
rm -rf jsoncpp-src
mv jsoncpp-src-0.6.0-rc2 jsoncpp-src
cp scons-local-2.1.0.tar.gz jsoncpp-src
cp CMakeLists.txt jsoncpp-src
cd jsoncpp-src
tar -xvf scons-local-2.1.0.tar.gz
python scons.py platform=linux-gcc

if [ ! -d "build" ]; then
    mkdir build
fi
cd build
cmake ..
make



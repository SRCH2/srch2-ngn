#ifndef elf32_h
#define elf32_h

#define ELF_CLASS	ELFCLASS32
#include "elfxx.h"

#endif /* elf32_h */

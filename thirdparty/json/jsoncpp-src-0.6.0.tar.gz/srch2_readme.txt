when you decided to upgrade the jsoncpp, please copy the CMakeLists.txt in the jsoncpp-src to your new jsoncpp.

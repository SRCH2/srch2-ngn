// This file intentionally blank.  shim_boost.cpp is part of the
// third_party/boost library, which is just a placeholder for forwarding
// library dependencies.

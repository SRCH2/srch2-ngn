:mod:`bulk` -- The bulk write operations interface
==================================================

.. automodule:: pymongo.bulk
   :synopsis: The bulk write operations interface.
   :members:
